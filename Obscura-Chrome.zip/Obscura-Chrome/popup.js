document.getElementById("save").onclick = () => {
  const config = {
    gpuVendor: document.getElementById("gpuVendor").value,
    gpuRenderer: document.getElementById("gpuRenderer").value,
    hardwareConcurrency: parseInt(document.getElementById("hardwareConcurrency").value),
    deviceMemory: parseInt(document.getElementById("deviceMemory").value),
    maxTouchPoints: parseInt(document.getElementById("maxTouchPoints").value),
  };

  chrome.storage.local.set({ spoofConfig: config }, () => {
    chrome.runtime.sendMessage({ updateBadge: true });
  });
};

// IP Fetch
function countryToFlagEmoji(code) {
  return code
    .toUpperCase()
    .replace(/./g, char => String.fromCodePoint(char.charCodeAt(0) + 127397));
}

fetch("https://ipapi.co/json/")
  .then(res => res.json())
  .then(data => {
    const ip = data.ip || "Unknown";
    const country = data.country || "";
    const flagImg = country
      ? `<img src="https://flagcdn.com/${country.toLowerCase()}.svg" width="18" style="vertical-align: middle; margin-left: 4px;" alt="${country} flag">`
      : "";
    document.getElementById("ip-info").innerHTML = `IP: ${ip} ${flagImg} ${country}`;
  })
  .catch(() => {
    document.getElementById("ip-info").innerText = "IP: Not available";
  });

const os = navigator.userAgentData?.platform || navigator.platform;
const resolution = `${screen.width} x ${screen.height}`;
const cpu = navigator.hardwareConcurrency || "Unknown";
const ram = navigator.deviceMemory ? navigator.deviceMemory + " GB" : "Unknown";
const chromeVersion = navigator.userAgent.match(/Chrome\/([\d.]+)/)?.[1] || "Unknown";

document.getElementById("device-info").innerHTML = `
  OS: ${os}<br>
  Resolution: ${resolution}<br>
  CPU Cores: ${cpu}<br>
  RAM: ${ram}<br>
  Chrome: ${chromeVersion}
`;
